const display = document.getElementById('display');
let expressao = "";

function adicionar(valor) {
if (display.value === '0' && !(isNaN(valor))) {
expressao = valor;
} else {
expressao += valor;
}
display.value = expressao;
}

function limpar() {
expressao = '';
display.value = '0';
}

function calcular() {
try {
const resultado = eval(expressao);
display.value = resultado;
expressao = resultado.toString();
} catch(e) {
display.value = 'Erro';
expressao = '';
}
}
